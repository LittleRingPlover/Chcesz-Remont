from django.http import Http404
from django.shortcuts import render

from .models import *


def index(request):
    context = {}
    return render(request, 'remonty/index.html', context)


def uslugi(request):
    services = Services.objects.all()
    context = {'services': services}
    return render(request, 'remonty/uslugi.html', context)


def about_us(request):
    info = AboutUs.objects.get()
    context = {'info': info}
    return render(request, 'remonty/o-nas.html', context)


def gallery(request):
    categories = Category.objects.all()
    cat_id = request.GET.get('categories')

    try:
        if cat_id and cat_id.isnumeric():
            category = Category.objects.get(pk=cat_id)
            filtered_images = Gallery.objects.filter(category=category).order_by('publication_date')
        else:
            filtered_images = Gallery.objects.all().order_by('publication_date')
    except Category.DoesNotExist:
        raise Http404("Wybrana kategoria nie istnieje.")

    context = {'filtered_images': filtered_images,
               'categories': categories}
    return render(request, 'remonty/galeria.html', context)


def contact(request):
    contact_info = Contact.objects.all
    context = {'contact_info': contact_info}
    return render(request, 'remonty/kontakt.html', context)
