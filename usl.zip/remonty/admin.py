from django.contrib import admin
from .models import AboutUs, ServiceDescription, Services, Category, Gallery, Contact
# Register your models here.

admin.site.register(AboutUs)
admin.site.register(ServiceDescription)
admin.site.register(Category)
admin.site.register(Services)
admin.site.register(Gallery)
admin.site.register(Contact)
