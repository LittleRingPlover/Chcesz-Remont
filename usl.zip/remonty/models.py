from django.db import models
from datetime import datetime


class AboutUs(models.Model):
    description = models.TextField()

    def __str__(self):
        return self.description


class ServiceDescription(models.Model):
    description = models.TextField()

    def __str__(self):
        return self.description


class Services(models.Model):
    service_type = models.CharField(max_length=200)

    def __str__(self):
        return self.service_type


class Category(models.Model):
    title = models.CharField(max_length=200)

    def __str__(self):
        return self.title


class Gallery(models.Model):
    title = models.CharField(max_length=200)
    publication_date = models.DateTimeField(auto_now_add=True)
    image = models.ImageField()
    category = models.ForeignKey(Category, on_delete=models.CASCADE, default=True)

    def __str__(self):
        return self.title


class Contact(models.Model):
    contact_type = models.TextField(max_length=200)
    phone_number = models.CharField(max_length=20)
    email = models.EmailField()
    social_media = models.URLField()

    def __str__(self):
        return self.contact_type
