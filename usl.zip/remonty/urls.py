from django.urls import path
from . import views


app_name = 'remonty'

urlpatterns = [
    path('', views.index, name='index'),
    path('uslugi/', views.uslugi, name='uslugi'),
    path('o-nas/', views.about_us, name='about_us'),
    path('galeria/', views.gallery, name='gallery'),
    path('kontakt/', views.contact, name='contact'),
]